package com.singlepointsol.authenticationdemo;

import android.app.Activity;

public class SigninActivity extends Activity {
}
