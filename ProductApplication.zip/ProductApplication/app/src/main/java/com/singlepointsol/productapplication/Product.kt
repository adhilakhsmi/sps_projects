package com.singlepointsol.productapplication

data class Product(
    val title: String,
    val id: String,
    val name: String,
    val price: String
)
