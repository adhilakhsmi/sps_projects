package com.singlepointsol.customerecyclerviewtask

data class Fruits(val fruitsImage:Int,val fruitsName:String  )
